-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 10:46 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `policedept`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ShowAllInfo` (IN `CaseID` INT)  READS SQL DATA
BEGIN

SET @FirID = (SELECT ca_fir_id FROM cases WHERE cases.ca_id = CaseID);
SET @PoliceID = (SELECT ca_po_id FROM cases WHERE cases.ca_id = CaseID);
SET @ComplainantID = (SELECT f_complainant_id FROM fir WHERE f_id = @FirID);
SET @VictimID  = (SELECT f_victim_id FROM fir WHERE f_id = @FirID);
SET @AccusedID  = (SELECT f_accused_id FROM fir WHERE f_id = @FirID);

SELECT * from cases WHERE cases.ca_id = @CaseID;
SELECT * from police_officer WHERE police_officer.po_id = @PoliceID;
SELECT * from fir WHERE fir.f_id = @FirID;
SELECT * from complainant WHERE complainant.co_id = @ComplainantID;
SELECT * from victim WHERE victim.vi_id = @VictimID;
SELECT * from accused WHERE accused.ac_id = @AccusedID;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accused`
--

CREATE TABLE `accused` (
  `ac_id` int(11) NOT NULL,
  `ac_name` varchar(25) NOT NULL,
  `ac_gender` char(1) NOT NULL,
  `ac_dob` date NOT NULL,
  `ac_phone` varchar(10) NOT NULL,
  `ac_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accused`
--

INSERT INTO `accused` (`ac_id`, `ac_name`, `ac_gender`, `ac_dob`, `ac_phone`, `ac_address`) VALUES
(1, 'Veerappan', 'm', '1970-11-05', '9966996699', 'Tiger Forest'),
(4, 'Maddy', 'm', '1994-01-01', '7412584632', 'Jalahalli, Bangalore'),
(5, 'Bharath', 'm', '1999-02-03', '9876543210', 'Kolar'),
(7, 'Sandy', 'f', '2001-12-05', '8569740123', 'Malleshwaram, Bangalore'),
(8, 'test', 'm', '1994-05-05', 'test', 'test'),
(9, 'test', 'm', '2019-10-30', 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ad_id` int(10) UNSIGNED NOT NULL,
  `ad_uname` varchar(10) NOT NULL,
  `ad_pwd` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ad_id`, `ad_uname`, `ad_pwd`) VALUES
(1, 'admin', '123'),
(2, 'admin2', '456');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `ca_id` int(10) NOT NULL,
  `ca_po_id` int(10) NOT NULL,
  `ca_fir_id` int(11) NOT NULL,
  `ca_desc` text NOT NULL,
  `ca_outcome` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`ca_id`, `ca_po_id`, `ca_fir_id`, `ca_desc`, `ca_outcome`) VALUES
(1, 102, 1, 'Murder', 'Solved. Accused sentenced for life in prision.'),
(5, 101, 5, 'Jewellery Theft', 'Solved. Jewellery recovered'),
(6, 103, 5, 'test desc', 'test');

--
-- Triggers `cases`
--
DELIMITER $$
CREATE TRIGGER `after_case_deleted` BEFORE DELETE ON `cases` FOR EACH ROW BEGIN
SET FOREIGN_KEY_CHECKS=0;
SET @FirID = (SELECT ca_fir_id FROM cases where ca_id = OLD.ca_id);
SET @ComplainantID = (SELECT f_complainant_id FROM fir WHERE f_id = @FirID);
SET @VictimID  = (SELECT f_victim_id FROM fir WHERE f_id = @FirID);
SET @AccusedID  = (SELECT f_accused_id FROM fir WHERE f_id = @FirID);

DELETE FROM fir WHERE fir.f_id = @FirID;
DELETE FROM complainant WHERE complainant.co_id = @ComplainantID;
DELETE FROM victim WHERE victim.vi_id = @VictimID;
DELETE FROM accused WHERE accused.ac_id = @AccusedID;
SET FOREIGN_KEY_CHECKS=1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `case_details`
-- (See below for the actual view)
--
CREATE TABLE `case_details` (
`CaseID` int(10)
,`FIRID` int(11)
,`Complainant` varchar(25)
,`Victim` varchar(25)
,`Accused` varchar(25)
,`POfficerID` int(10)
,`PoliceOfficer` varchar(30)
,`Description` text
,`Outcome` text
);

-- --------------------------------------------------------

--
-- Table structure for table `complainant`
--

CREATE TABLE `complainant` (
  `co_id` int(11) NOT NULL,
  `co_name` varchar(25) NOT NULL,
  `co_gender` char(1) NOT NULL,
  `co_dob` varchar(10) NOT NULL,
  `co_phone` varchar(10) NOT NULL,
  `co_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complainant`
--

INSERT INTO `complainant` (`co_id`, `co_name`, `co_gender`, `co_dob`, `co_phone`, `co_address`) VALUES
(1, 'Ashish', 'm', '1997-07-12', '8550022182', 'Hebbal, Bangalore'),
(13, 'Priya', 'f', '1996-02-16', '9542130781', 'Mathikere, Bangalore'),
(14, 'Sachin', 'm', '1996-08-22', '6541237890', 'Mysore'),
(19, 'Nithya', 'f', '1998-05-09', '9902363984', 'Malleshwaram, Bangalore'),
(20, 'abc', 'm', '2017-01-01', '4849845668', 'ghjhfjtduytc'),
(21, 'test', 'm', '2019-11-01', '9874563201', 'Malleshwaram, Bangalore');

-- --------------------------------------------------------

--
-- Table structure for table `fir`
--

CREATE TABLE `fir` (
  `f_id` int(11) NOT NULL,
  `f_complainant_id` int(11) NOT NULL,
  `f_victim_id` int(11) NOT NULL,
  `f_accused_id` int(11) NOT NULL,
  `f_date_file` date NOT NULL,
  `f_date_incident` date NOT NULL,
  `f_place_incident` varchar(25) NOT NULL,
  `f_crime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fir`
--

INSERT INTO `fir` (`f_id`, `f_complainant_id`, `f_victim_id`, `f_accused_id`, `f_date_file`, `f_date_incident`, `f_place_incident`, `f_crime`) VALUES
(1, 1, 1, 1, '2019-10-25', '2019-10-24', 'Hebbal, Bangalore', 'theft'),
(5, 14, 5, 5, '2019-11-04', '2019-11-03', 'Bangalore', 'Theft'),
(10, 19, 7, 7, '2019-10-31', '2019-10-29', 'Malleshwaram', 'Theft'),
(11, 20, 9, 8, '2019-11-06', '2019-11-05', 'Bangalore', 'Theft'),
(12, 21, 10, 9, '2019-10-30', '2019-10-28', 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `police_officer`
--

CREATE TABLE `police_officer` (
  `po_id` int(10) NOT NULL,
  `po_uname` varchar(10) NOT NULL,
  `po_pwd` varchar(15) NOT NULL,
  `po_name` varchar(30) NOT NULL,
  `po_rank` varchar(10) NOT NULL,
  `po_phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `police_officer`
--

INSERT INTO `police_officer` (`po_id`, `po_uname`, `po_pwd`, `po_name`, `po_rank`, `po_phone`) VALUES
(101, 'singham', '123', 'Bajirao Singham', 'Inspector', '9128456321'),
(102, 'vishnu', 'police1', 'Vishnu Vardhan', 'DGP', '9865327410'),
(103, 'vikram', '789', 'Vikram Rathod', 'Inspector', '5416894126'),
(104, 'dboss', 'qwer1234', 'Darshan', 'ACP', '9874563201');

-- --------------------------------------------------------

--
-- Table structure for table `victim`
--

CREATE TABLE `victim` (
  `vi_id` int(11) NOT NULL,
  `vi_name` varchar(25) NOT NULL,
  `vi_gender` char(1) NOT NULL,
  `vi_dob` date NOT NULL,
  `vi_phone` varchar(10) NOT NULL,
  `vi_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `victim`
--

INSERT INTO `victim` (`vi_id`, `vi_name`, `vi_gender`, `vi_dob`, `vi_phone`, `vi_address`) VALUES
(1, 'Shashank', 'M', '1997-01-12', '8745216540', 'Vijaypur, Bangalore'),
(2, 'Priya', 'f', '2019-11-12', '7412584632', 'Mathikere, Bangalore'),
(5, 'Vinay', 'm', '1997-11-14', '8521479630', 'Kolar'),
(7, 'Nithya', 'f', '1998-05-09', '9902363984', 'Malleshwaram, Bangalore'),
(8, '', '', '0000-00-00', '', ''),
(9, 'test', 'm', '1996-02-02', 'test', 'test2'),
(10, 'test', 'm', '2019-10-29', 'test', 'test');

-- --------------------------------------------------------

--
-- Structure for view `case_details`
--
DROP TABLE IF EXISTS `case_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `case_details`  AS  select `c`.`ca_id` AS `CaseID`,`f`.`f_id` AS `FIRID`,`co`.`co_name` AS `Complainant`,`v`.`vi_name` AS `Victim`,`a`.`ac_name` AS `Accused`,`po`.`po_id` AS `POfficerID`,`po`.`po_name` AS `PoliceOfficer`,`c`.`ca_desc` AS `Description`,`c`.`ca_outcome` AS `Outcome` from (((((`cases` `c` join `fir` `f`) join `complainant` `co`) join `victim` `v`) join `accused` `a`) join `police_officer` `po`) where ((`c`.`ca_fir_id` = `f`.`f_id`) and (`f`.`f_accused_id` = `a`.`ac_id`) and (`f`.`f_victim_id` = `v`.`vi_id`) and (`co`.`co_id` = `f`.`f_complainant_id`) and (`po`.`po_id` = `c`.`ca_po_id`)) group by `c`.`ca_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accused`
--
ALTER TABLE `accused`
  ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ad_id`),
  ADD UNIQUE KEY `ad_uname` (`ad_uname`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`ca_id`),
  ADD KEY `ca_fir_id` (`ca_fir_id`),
  ADD KEY `ca_po_id` (`ca_po_id`);

--
-- Indexes for table `complainant`
--
ALTER TABLE `complainant`
  ADD PRIMARY KEY (`co_id`);

--
-- Indexes for table `fir`
--
ALTER TABLE `fir`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `f_complainant_id` (`f_complainant_id`),
  ADD KEY `f_victim_id` (`f_victim_id`),
  ADD KEY `f_accused_id` (`f_accused_id`);

--
-- Indexes for table `police_officer`
--
ALTER TABLE `police_officer`
  ADD PRIMARY KEY (`po_id`),
  ADD UNIQUE KEY `po_uname` (`po_uname`);

--
-- Indexes for table `victim`
--
ALTER TABLE `victim`
  ADD PRIMARY KEY (`vi_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accused`
--
ALTER TABLE `accused`
  MODIFY `ac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `ca_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `complainant`
--
ALTER TABLE `complainant`
  MODIFY `co_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `fir`
--
ALTER TABLE `fir`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `police_officer`
--
ALTER TABLE `police_officer`
  MODIFY `po_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `victim`
--
ALTER TABLE `victim`
  MODIFY `vi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`ca_fir_id`) REFERENCES `fir` (`f_id`),
  ADD CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`ca_fir_id`) REFERENCES `fir` (`f_id`),
  ADD CONSTRAINT `cases_ibfk_3` FOREIGN KEY (`ca_po_id`) REFERENCES `police_officer` (`po_id`);

--
-- Constraints for table `fir`
--
ALTER TABLE `fir`
  ADD CONSTRAINT `fir_ibfk_1` FOREIGN KEY (`f_complainant_id`) REFERENCES `complainant` (`co_id`),
  ADD CONSTRAINT `fir_ibfk_2` FOREIGN KEY (`f_victim_id`) REFERENCES `victim` (`vi_id`),
  ADD CONSTRAINT `fir_ibfk_3` FOREIGN KEY (`f_accused_id`) REFERENCES `accused` (`ac_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
